Organic Chemistry 1 — student project

1. Extract this ZIP into an ordinary folder.
2. Open organic-chemistry.Rproj in RStudio.
3. Open report.Rmd, replace the author, save and Knit to HTML.
4. Read data/README.md for units, provenance and sample meanings.

All data are constructed teaching examples. No experiment has been performed.
The IR traces are schematic models, not measured reference spectra. The IR
comparison in the report is unrelated to the aspirin isolation table.

Packages: readr, dplyr, ggplot2, knitr, rmarkdown.
Keep report.Rmd beside data/; keep raw CSVs unchanged.
Add your unit exercises to the report and save derived files in output/.
Restart R and Knit before sharing the report with its data and source.
